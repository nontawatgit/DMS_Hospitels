<?php
$host = "localhost";
$username = "id19516823_dms_user";
$password = "xEGo7PV!A<{q&xVI";
$db = "id19516823_dms_name";
?>